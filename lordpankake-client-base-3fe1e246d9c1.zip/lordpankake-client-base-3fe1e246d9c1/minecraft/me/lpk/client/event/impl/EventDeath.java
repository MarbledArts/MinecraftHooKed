package me.lpk.client.event.impl;

import me.lpk.client.event.Event;

public class EventDeath extends Event {

}
