package me.lpk.client.event.impl;

import me.lpk.client.event.Event;
import net.minecraft.network.Packet;

public class EventTick extends Event {
	
}
