package me.lpk.client.util;

import net.minecraft.client.Minecraft;

public interface MinecraftUtil {
	static final Minecraft mc = Minecraft.getMinecraft();
}
