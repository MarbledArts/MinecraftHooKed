package me.lpk.client.account.relation;

public enum EnumRelationship {
	Friend, Rival, Neutral
}
