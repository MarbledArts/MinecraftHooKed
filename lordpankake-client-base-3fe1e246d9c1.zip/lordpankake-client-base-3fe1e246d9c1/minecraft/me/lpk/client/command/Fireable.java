package me.lpk.client.command;

public interface Fireable {
	public void fire(String[] args);
}
