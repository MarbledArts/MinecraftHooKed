package me.lpk.client.module.impl.world;

import org.lwjgl.input.Keyboard;

import me.lpk.client.event.Event;
import me.lpk.client.event.RegisterEvent;
import me.lpk.client.event.impl.EventPacket;
import me.lpk.client.event.impl.EventTick;
import me.lpk.client.keybinding.KeyMask;
import me.lpk.client.module.Module;
import me.lpk.client.module.data.ModuleData;
import me.lpk.client.module.data.Setting;
import me.lpk.client.util.misc.Timer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class LiquidInteract extends Module {
	public LiquidInteract(ModuleData data) {
		super(data);
	}

	@Override
	@RegisterEvent(events = { EventPacket.class })
	public void onEvent(Event event) {
		// TODO: NoCheatPlus bypass
		/**
		 * EventPacket
		 * ep=(EventPacket)event;if(ep.isIncoming()){return;}if(ep.getPacket()
		 * instanceof
		 * C08PacketPlayerBlockPlacement){C08PacketPlayerBlockPlacement
		 * p=(C08PacketPlayerBlockPlacement)ep.getPacket();BlockPos
		 * placePos=p.getBlockPos();BlockPos placeUnderPos=new
		 * BlockPos(placePos.getX(),placePos.getY()-1,placePos.getZ());Block
		 * placeBlock=mc.theWorld.getBlockState(placePos).getBlock();Block
		 * placeUnderBlock=mc.theWorld.getBlockState(placeUnderPos).getBlock();
		 * if(placeBlock.getMaterial()==Material.air)
		 * {mc.thePlayer.sendQueue.addToSendQueue(new
		 * C08PacketPlayerBlockPlacement(
		 * placeUnderPos,p.getPlacedBlockDirection(),
		 * mc.thePlayer.inventory.getCurrentItem(),p.getPlacedBlockOffsetX(),
		 * p.getPlacedBlockOffsetY(),
		 * p.getPlacedBlockOffsetZ()));event.setCancelled(true);}p.setBlockPos(
		 * placeUnderPos)}
		 */
	}
}
