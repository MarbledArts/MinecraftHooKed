package me.lpk.client.gui.clickgui;

public interface GUILinked {
	void onItemClick();

	void onItemRelease();
}
